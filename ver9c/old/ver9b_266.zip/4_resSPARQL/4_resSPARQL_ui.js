// Ссылка на issue: https://github.com/bpmbpm/rdf-grapher/issues/232
// 4_resSPARQL_ui.js - UI модуль панели Result in SPARQL
// HTML разметка панели определена в index.html
// Логика создания и применения SPARQL запросов находится в 3_sd/3_sd_logic.js
