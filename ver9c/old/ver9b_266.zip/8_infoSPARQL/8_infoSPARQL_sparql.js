// Ссылка на issue: https://github.com/bpmbpm/rdf-grapher/issues/232
// 8_infoSPARQL_sparql.js - SPARQL запросы для панели SPARQL запросов
// Основные SPARQL запросы определены в 3_sd/3_sd_sparql.js
// Этот файл предназначен для дополнительных запросов, специфичных для модуля
