### ver9b
Smart Design + Ontology + SPARQL   
на основе ver8tree  

### run

https://bpmbpm.github.io/rdf-grapher/ver9b/  


*Загрузить пример RDF данных:*  
выбрать (choose): **Trig VADv5**   
Нажать кнопку (press the button) **Показать**  
В Дерево TriG выбирать объекты, схемы или процессы. При выборе схема - в окне Диаграмма отобразится схема процесса.
