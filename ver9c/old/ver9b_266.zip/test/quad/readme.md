## test
### Create & Deleta Concept
- https://bpmbpm.github.io/rdf-grapher/ver9b/test/quad/test_simple_triple.html
- https://bpmbpm.github.io/rdf-grapher/ver9b/test/quad/test_shorthand_triple.html
- https://bpmbpm.github.io/rdf-grapher/ver9b/test/quad/test_mixed_triple.html
