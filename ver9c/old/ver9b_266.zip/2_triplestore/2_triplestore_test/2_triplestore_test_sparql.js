// Ссылка на issue: https://github.com/bpmbpm/rdf-grapher/issues/232
// 2_triplestore_test_sparql.js - SPARQL запросы для модуля тестирования
// В текущей версии тестирование использует функции из vadlib и vad-validation-rules.js
// SPARQL запросы для тестирования могут быть добавлены при расширении функциональности
