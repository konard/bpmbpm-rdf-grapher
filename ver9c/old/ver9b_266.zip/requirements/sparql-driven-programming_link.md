## sparql-driven-programming
- ver9b sparql-driven-programming_min1.md
- quadstore (TriG) and SPARQL https://github.com/bpmbpm/doc/blob/main/LD2/Problem/problem1.md
- initial ver8tree https://github.com/bpmbpm/rdf-grapher/blob/main/ver8tree/doc/sparql-driven-programming.md
