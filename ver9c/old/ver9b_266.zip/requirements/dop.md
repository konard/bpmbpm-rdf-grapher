## BEST-PRACTICES
- дать ему ссылку на - https://github.com/link-assistant/hive-mind/blob/main/docs/BEST-PRACTICES.md, чтобы он тебе CI/CD обновил взяв лучшие практики для твоего языка отсюда.
- надо меньше - 1000-1500 строк кода

## DOC
- hive-mind https://github.com/link-assistant/hive-mind/blob/main/docs/CONFIGURATION.md документация по всем опциям

## Code
- 5. Модульность кода https://github.com/bpmbpm/rdf-grapher/blob/main/ver8/comment8a.md
- ver7so/ Предложения для алгоритма обработки https://github.com/bpmbpm/rdf-grapher/blob/main/ver7so/comment1.md ; https://github.com/bpmbpm/rdf-grapher/blob/main/ver7so/comment2.md ;
  - Таблица «Объект-Предикат»: https://github.com/bpmbpm/rdf-grapher/blob/main/ver7so/comment3.md
  - Smart Design - Справка по работе https://github.com/bpmbpm/rdf-grapher/blob/main/ver7so/help.md
  - https://github.com/bpmbpm/rdf-grapher/blob/main/ver7so/info.md
  - https://github.com/bpmbpm/rdf-grapher/blob/main/ver7so/predicate.xlsx
 
## 2
- Он контекст компактифицирует, т.к. в один контекст не влезла. Это долго. У тебя задача слишком большая получилась. https://t.me/c/2975819706/1603/54174 Если не предлагает Merge, то ready for review
А как узнать, что нужно уже жать кнопку ready for review или есть надежда и еще подождать? 
- https://github.com/bpmbpm/rdf-grapher/tree/main/ver8tree/requirements