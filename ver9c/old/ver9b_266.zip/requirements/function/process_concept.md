## process concept
Создание и удаление концепта процесса. 
### New concept process
Функциональные требования к Созданию концепта процесса.  При создании Концепта процесса. 
Не забыть проверки: 
- отсутствие одноименного в ptree (имеющегося c таким же именем), допустимость id (укажи ограничения quadstore на формат id для subject).
- 

### requirements arc
- https://github.com/bpmbpm/rdf-grapher/blob/main/ver8tree/requirements/business-requirements.md
- 1 Добавь кнопку New Concept в окно Smart Design.
  - https://github.com/bpmbpm/rdf-grapher/issues/205
  - https://github.com/bpmbpm/rdf-grapher/issues/207
- https://github.com/bpmbpm/rdf-grapher/issues/211 По аналогии с кнопкой "New Concept" создай кнопку "Del Concept\Individ" (delete), удаляющую существующий концепт или индивид.

### Требования не сюда:
- Запись нового элемента TriG осуществляется в конец TriG. - это к реализации SPARQL - запроса, а не его созданию, т.е. требование к Result. Создание Концепта тут не при чем. 
