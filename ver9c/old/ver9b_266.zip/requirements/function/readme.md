## function requirements
