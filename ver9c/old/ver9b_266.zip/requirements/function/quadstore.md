## quadstore I/O
Фактически речь идет о переработки кнопок отработки SPARQL - запросов

### output
Вывод - окно "SPARQL - запрос"

### input
Result in SPARQL
