## doc
### also
- https://github.com/bpmbpm/rdf-grapher/blob/main/ver8tree/doc/ui-documentation.md
